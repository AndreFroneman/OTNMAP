# OTNMAP

**OTNMAP** is a safety-first OT/ICS network discovery and inventory platform.

It is designed around four principles:

1. **Passive first** — learn from mirrored traffic before transmitting.
2. **Explicit safety budgets** — low concurrency, long timeouts, jitter, allowlists, and per-host probe limits.
3. **Protocol-aware discovery** — understand OT protocols rather than treating every service as generic TCP.
4. **Evidence-based output** — every finding records how it was observed and its confidence.

> Use only on networks you own or are explicitly authorized to assess. Begin with passive capture on a TAP/SPAN port. Obtain OEM and change-control approval before active probing production OT assets.

## Included in this starter

- Typer CLI
- FastAPI REST API and simple web dashboard
- SQLite inventory
- Passive ARP, LLDP, CDP, OSPF and VRRP observation
- Conservative TCP connect discovery
- OPC UA endpoint discovery using `GetEndpoints`
- Optional authorized SNMP collection for ARP and route tables
- JSON, CSV, NDJSON and HTML exports
- Risk/safety policy engine
- Explainable heuristic “AI-style” asset classification and anomaly scoring
- Docker Compose deployment for Debian

## Architecture

```text
TAP/SPAN / PCAP ──> Passive Sensor ─┐
                                    ├─> Evidence Normalizer ─> SQLite
Safe Active Probes ────────────────>│                         ├─> CLI/API/UI
SNMPv3 / future SSH adapters ──────>┘                         └─> Export/Reports
```

## Quick start on Debian

```bash
cp .env.example .env
docker compose build
docker compose up -d
docker compose exec otnmap otnmap init-db
docker compose exec otnmap otnmap status
```

Dashboard: `http://localhost:8080`

Passive capture requires host networking and capture privileges. Set `OTNMAP_INTERFACE` to the TAP/SPAN interface in `.env`, then:

```bash
docker compose exec otnmap otnmap passive --interface eth1 --seconds 300
```

Safe discovery of an approved subnet:

```bash
docker compose exec otnmap otnmap discover 192.168.10.0/24 \
  --profile fragile \
  --ports 22,80,443,102,502,4840,44818,20000,47808
```

OPC UA endpoint discovery:

```bash
docker compose exec otnmap otnmap opcua opc.tcp://192.168.10.20:4840
```

Authorized SNMPv3 collection:

```bash
docker compose exec otnmap otnmap snmp-tables 192.168.10.1 \
  --user otnmap_ro --auth-key '...' --priv-key '...'
```

Export:

```bash
docker compose exec otnmap otnmap export --format html --output /data/report.html
```

## Safety profiles

| Profile | Concurrency | Delay | Per-host packets | Intended use |
|---|---:|---:|---:|---|
| `observe` | 0 | n/a | 0 | Passive only |
| `fragile` | 1 | 750 ms + jitter | 12 | PLCs, legacy HMIs, unknown production assets |
| `conservative` | 4 | 250 ms + jitter | 50 | Approved OT discovery |
| `lab` | 32 | 10 ms | 500 | Test environments only |

OTNMAP intentionally excludes aggressive version detection, brute force, malformed packets, vulnerability exploitation, and broad UDP blasting.

## Protocol roadmap

- **Implemented starter:** ARP, LLDP, CDP, OSPF, VRRP, TCP connect, OPC UA discovery, SNMPv3 tables
- **Next:** EtherNet/IP ListIdentity, Modbus Device Identification, S7 identification, DNP3 link status, BACnet Who-Is with strict broadcast controls, PROFINET DCP passive decoding
- **Later:** IEC 61850 MMS/GOOSE, HART-IP, FINS, MELSEC, IEC 60870-5-104, vendor-specific enrichment

Each active plugin should define:
- exact packets sent;
- maximum requests;
- known fragile devices;
- stop conditions;
- expected response;
- evidence and confidence;
- OEM approval notes.

## AI features

The starter uses deterministic, explainable scoring rather than sending OT data to a cloud model:

- asset-role classification from ports, protocol evidence, MAC/OUI and behavior;
- confidence scores;
- unusual service/protocol combinations;
- newly observed asset detection;
- duplicate-IP and MAC movement warnings;
- natural-language report summaries.

A local LLM adapter can later use Ollama, but it should consume normalized metadata, not raw process values or credentials.

## “Any network device” limitation

Passive capture reveals ARP messages and routing advertisements visible at the sensor. It cannot magically read an internal forwarding information base or full ARP cache. Full tables require authorized SNMP, SSH/NETCONF/RESTCONF, or vendor APIs. OTNMAP records the collection source so passive inference is never confused with authoritative device state.
