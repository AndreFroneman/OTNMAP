# OTNMAP Product Vision

## Product name
**OTNMAP — Operational Technology Network Mapper**

## Differentiator
OTNMAP is not “Nmap with more ports.” It is an OT evidence platform that treats uptime, process safety, protocol semantics, collection provenance, and operator approval as first-class design requirements.

## Core operating modes
1. Observe: no packets transmitted.
2. Verify: narrowly confirm already observed services.
3. Discover: approved low-impact protocol discovery.
4. Manage: use authenticated read-only APIs to retrieve authoritative tables.
5. Lab: deeper protocol fingerprinting in non-production environments.

## Safety interlocks
- Active mode cannot run without an explicit profile.
- CIDR allowlist and optional denylist.
- Per-host and per-protocol request budgets.
- Broadcast and multicast disabled unless separately approved.
- Automatic stop on latency increase, reset storms, ICMP errors or operator stop.
- Maintenance-window controls.
- Device fragility registry.
- Packet preview and dry run.
- Cryptographically signed scan plan and audit log (future).
- No write requests to industrial protocols.
- No exploit or credential attack modules.

## Plugin contract
Every plugin must expose:
- metadata and protocol;
- passive signatures;
- safe active request sequence;
- risk class;
- packet count;
- minimum spacing;
- stop conditions;
- data classification;
- normalized evidence schema;
- test PCAPs and simulator tests.

## Export targets
- JSON / NDJSON / CSV / HTML
- CycloneDX or custom OT SBOM
- STIX 2.1 observations
- Syslog / CEF / LEEF
- Splunk HEC, Elastic, Sentinel, QRadar
- NetBox, Nautobot and ServiceNow CMDB
- Grafana/Prometheus metrics
- PCAP evidence references
- IEC 62443 zone/conduit candidate map
- Visio/draw.io/GraphML topology output

## Local AI roadmap
- Explainable role and vendor classifier.
- Baseline learning by site/zone/shift.
- Asset identity reconciliation.
- Suggested zones and conduits.
- Change summaries.
- “Why do we believe this is a PLC?” evidence trace.
- Local Ollama report assistant with redaction.
- Retrieval over OEM manuals supplied by the operator.
- Never autonomously launch probes.
