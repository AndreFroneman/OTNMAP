# Safe Protocol Matrix

| Protocol | Passive | Initial active action | Default risk | Notes |
|---|---|---|---|---|
| ARP | Observe requests/replies | None needed | Low | Active ARP sweeps disabled in observe mode |
| LLDP/CDP | Decode advertisements | None | Low | Layer-2 visibility only |
| OPC UA | Detect hello/traffic | GetEndpoints only | Low–medium | No session browse or reads by default |
| EtherNet/IP | Decode CIP/encapsulation | ListIdentity, unicast | Medium | Strict request cap |
| Modbus TCP | Decode function codes | MEI device identification where supported | Medium | Never read arbitrary registers by default |
| S7 | Decode COTP/S7Comm | Minimal identification in approved mode | Medium–high | Fragility registry required |
| BACnet/IP | Decode traffic | Directed request preferred | Medium | Broadcast Who-Is separately gated |
| DNP3 | Decode link/application headers | Link status only | Medium | No control operations |
| IEC 104 | Decode ASDUs | TCP service confirmation only initially | Medium | Avoid STARTDT in fragile mode |
| PROFINET DCP | Decode multicast | Identify request only when approved | Medium | Layer-2 broadcast risk |
| SNMPv3 | Observe | Authenticated GET/WALK | Low–medium | Read-only account; device rate limits |
