import json
from collections import defaultdict
from .db import SessionLocal, Observation

ROLE_RULES = {
    "PLC/Controller": {"S7/RFC1006", "ModbusTCP", "EtherNetIP", "OMRON-FINS-TCP"},
    "OPC UA Server": {"OPCUA"},
    "Protection/SCADA Device": {"DNP3", "IEC104"},
    "Building Controller": {"BACnetIP"},
    "Network Infrastructure": {"LLDP", "CDP", "OSPF", "VRRP", "SNMPv3"},
}

def classify_assets():
    evidence = defaultdict(set)
    with SessionLocal() as db:
        rows = db.query(Observation).all()
    for row in rows:
        if row.ip and row.protocol:
            evidence[row.ip].add(row.protocol)

    results = []
    for ip, protocols in evidence.items():
        scores = []
        for role, indicators in ROLE_RULES.items():
            overlap = protocols & indicators
            if overlap:
                scores.append((len(overlap) / len(indicators), role, sorted(overlap)))
        scores.sort(reverse=True)
        if scores:
            score, role, matched = scores[0]
            confidence = min(0.99, 0.55 + 0.15 * len(matched))
        else:
            role, confidence, matched = "Unknown OT/IT Asset", 0.3, []
        results.append({
            "ip": ip, "role": role, "confidence": confidence,
            "evidence": sorted(protocols), "matched_indicators": matched
        })
    return results
