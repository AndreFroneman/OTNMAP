from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from .db import init_db, SessionLocal, Observation
from .ai import classify_assets

app = FastAPI(title="OTNMAP", version="0.1.0")

@app.on_event("startup")
def startup():
    init_db()

@app.get("/api/assets")
def assets():
    return classify_assets()

@app.get("/api/observations")
def observations(limit: int = 500):
    with SessionLocal() as db:
        rows = db.query(Observation).order_by(Observation.timestamp.desc()).limit(min(limit, 5000)).all()
        return [{
            "timestamp": x.timestamp, "source": x.source, "kind": x.kind,
            "ip": x.ip, "mac": x.mac, "protocol": x.protocol,
            "port": x.port, "confidence": x.confidence, "details": x.details
        } for x in rows]

@app.get("/", response_class=HTMLResponse)
def home():
    return """<!doctype html><html><head><meta charset='utf-8'><title>OTNMAP</title>
    <style>body{font:16px system-ui;margin:2rem;background:#10151b;color:#e8eef5}
    h1{font-size:2.2rem}.card{background:#18212b;padding:1rem;border-radius:12px;margin:.8rem 0}
    table{width:100%;border-collapse:collapse}td,th{padding:.5rem;border-bottom:1px solid #334}
    .muted{color:#9fb0c0}</style></head><body><h1>OTNMAP</h1>
    <p class='muted'>Safety-first OT/ICS discovery and evidence platform</p>
    <div class='card'><h2>Assets</h2><table id='assets'></table></div>
    <script>
    fetch('/api/assets').then(r=>r.json()).then(xs=>{
      document.querySelector('#assets').innerHTML =
      '<tr><th>IP</th><th>Role</th><th>Confidence</th><th>Evidence</th></tr>'+
      xs.map(x=>`<tr><td>${x.ip}</td><td>${x.role}</td><td>${Math.round(x.confidence*100)}%</td><td>${x.evidence.join(', ')}</td></tr>`).join('')
    })</script></body></html>"""
