import asyncio, json, os
import typer
from rich import print
from rich.table import Table
from .db import init_db, SessionLocal, Observation
from .passive import capture
from .discovery import discover_network
from .opcua import discover_endpoints
from .snmp import collect_tables
from .ai import classify_assets
from .exporter import export as run_export

app = typer.Typer(help="OTNMAP — safety-first OT/ICS discovery")

@app.command("init-db")
def init_database():
    init_db()
    print("[green]Database initialized[/green]")

@app.command()
def status():
    init_db()
    with SessionLocal() as db:
        count = db.query(Observation).count()
    print({"database": os.getenv("OTNMAP_DB", "sqlite:///otnmap.db"), "observations": count})

@app.command()
def passive(interface: str = typer.Option(...), seconds: int = 60, pcap: str | None = None):
    init_db()
    print(f"Passive capture on {interface} for {seconds}s")
    capture(interface, seconds, pcap)

@app.command()
def discover(
    cidr: str,
    profile: str = typer.Option("fragile"),
    ports: str = typer.Option("22,80,443,102,502,4840,44818,20000,47808")
):
    init_db()
    parsed = [int(x.strip()) for x in ports.split(",") if x.strip()]
    asyncio.run(discover_network(cidr, parsed, profile))
    print("[green]Discovery complete[/green]")

@app.command()
def opcua(url: str):
    init_db()
    result = asyncio.run(discover_endpoints(url))
    print_json(result)

@app.command("snmp-tables")
def snmp_tables(host: str, user: str, auth_key: str, priv_key: str):
    init_db()
    result = asyncio.run(collect_tables(host, user, auth_key, priv_key))
    print_json(result)

@app.command()
def assets():
    init_db()
    print_json(classify_assets())

@app.command()
def export(
    format: str = typer.Option("json"),
    output: str = typer.Option("/data/otnmap-report.json")
):
    init_db()
    run_export(format, output)
    print(f"[green]Wrote {output}[/green]")

def print_json(value):
    print(json.dumps(value, indent=2, default=str))

if __name__ == "__main__":
    app()
