import asyncio, ipaddress, json, socket
from .db import SessionLocal, Observation
from .policy import PROFILES

OT_PORTS = {
    102: "S7/RFC1006", 502: "ModbusTCP", 4840: "OPCUA",
    44818: "EtherNetIP", 20000: "DNP3", 47808: "BACnetIP",
    2404: "IEC104", 9600: "OMRON-FINS-TCP"
}

async def _connect(ip: str, port: int, timeout: float = 1.5):
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout)
        writer.close()
        await writer.wait_closed()
        return True
    except (OSError, asyncio.TimeoutError):
        return False

async def discover_network(cidr: str, ports: list[int], profile_name: str):
    profile = PROFILES[profile_name]
    if not profile.active:
        raise ValueError("The observe profile forbids active probes.")
    network = ipaddress.ip_network(cidr, strict=False)
    semaphore = asyncio.Semaphore(profile.concurrency)

    async def probe(ip, port):
        async with semaphore:
            await asyncio.sleep((profile.base_delay_ms / 1000))
            is_open = await _connect(str(ip), port)
            if is_open:
                protocol = OT_PORTS.get(port, "TCP")
                with SessionLocal() as db:
                    db.add(Observation(
                        source="active-safe", kind="open_port", ip=str(ip),
                        port=port, protocol=protocol, confidence=0.75,
                        details=json.dumps({"profile": profile.name, "method": "tcp_connect"})
                    ))
                    db.commit()

    tasks = []
    for ip in network.hosts():
        for port in ports[:profile.max_probes_per_host]:
            tasks.append(asyncio.create_task(probe(ip, port)))
    await asyncio.gather(*tasks)
