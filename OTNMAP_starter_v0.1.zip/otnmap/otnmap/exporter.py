import csv, json
from pathlib import Path
from jinja2 import Template
from .db import SessionLocal, Observation
from .ai import classify_assets

def _rows():
    with SessionLocal() as db:
        return [
            {
                "timestamp": str(x.timestamp), "source": x.source, "kind": x.kind,
                "ip": x.ip, "mac": x.mac, "protocol": x.protocol,
                "port": x.port, "confidence": x.confidence,
                "details": json.loads(x.details or "{}")
            }
            for x in db.query(Observation).order_by(Observation.timestamp).all()
        ]

def export(fmt: str, output: str):
    rows = _rows()
    path = Path(output)
    if fmt == "json":
        path.write_text(json.dumps({"observations": rows, "assets": classify_assets()}, indent=2))
    elif fmt == "ndjson":
        path.write_text("\n".join(json.dumps(x) for x in rows) + "\n")
    elif fmt == "csv":
        with path.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "timestamp","source","kind","ip","mac","protocol","port","confidence","details"])
            writer.writeheader()
            for row in rows:
                row["details"] = json.dumps(row["details"])
                writer.writerow(row)
    elif fmt == "html":
        template = Template("""<!doctype html><html><head><meta charset="utf-8">
        <title>OTNMAP Report</title><style>
        body{font-family:system-ui;margin:2rem;max-width:1400px}table{border-collapse:collapse;width:100%}
        th,td{border:1px solid #ddd;padding:.45rem;text-align:left}th{background:#eee}
        code{white-space:pre-wrap;font-size:.8rem}</style></head><body>
        <h1>OTNMAP Discovery Report</h1><h2>Classified assets</h2>
        <table><tr><th>IP</th><th>Role</th><th>Confidence</th><th>Evidence</th></tr>
        {% for a in assets %}<tr><td>{{a.ip}}</td><td>{{a.role}}</td>
        <td>{{"%.0f"|format(a.confidence*100)}}%</td><td>{{a.evidence|join(", ")}}</td></tr>{% endfor %}
        </table><h2>Evidence</h2><table><tr><th>Time</th><th>Source</th><th>IP</th>
        <th>Protocol</th><th>Kind</th><th>Details</th></tr>
        {% for r in rows %}<tr><td>{{r.timestamp}}</td><td>{{r.source}}</td><td>{{r.ip or ""}}</td>
        <td>{{r.protocol or ""}}</td><td>{{r.kind}}</td><td><code>{{r.details}}</code></td></tr>{% endfor %}
        </table></body></html>""")
        path.write_text(template.render(rows=rows, assets=classify_assets()))
    else:
        raise ValueError("Supported formats: json, ndjson, csv, html")
