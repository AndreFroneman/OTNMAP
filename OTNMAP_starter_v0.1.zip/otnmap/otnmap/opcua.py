import json
from asyncua import Client
from .db import SessionLocal, Observation

async def discover_endpoints(url: str):
    # Discovery only: no session browsing, reads, writes, subscriptions, or method calls.
    client = Client(url=url, timeout=4)
    endpoints = await client.connect_and_get_server_endpoints()
    results = []
    for ep in endpoints:
        item = {
            "endpoint_url": ep.EndpointUrl,
            "security_mode": str(ep.SecurityMode),
            "security_policy": ep.SecurityPolicyUri,
            "transport_profile": ep.TransportProfileUri,
            "security_level": int(ep.SecurityLevel),
        }
        results.append(item)

    host = url.split("://", 1)[-1].split(":", 1)[0]
    with SessionLocal() as db:
        db.add(Observation(
            source="active-safe", kind="opcua_endpoints", ip=host,
            port=4840, protocol="OPCUA", confidence=0.98,
            details=json.dumps({"url": url, "endpoints": results})
        ))
        db.commit()
    return results
