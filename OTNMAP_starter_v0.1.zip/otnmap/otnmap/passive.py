import json
from scapy.all import sniff, ARP, Ether, IP
from .db import SessionLocal, Observation

def _save(**kwargs):
    with SessionLocal() as db:
        db.add(Observation(**kwargs))
        db.commit()

def handle_packet(pkt):
    if ARP in pkt:
        arp = pkt[ARP]
        _save(
            source="passive", kind="arp", ip=arp.psrc or None,
            mac=arp.hwsrc or None, protocol="ARP", confidence=0.95,
            details=json.dumps({"operation": int(arp.op), "target_ip": arp.pdst})
        )
        return

    if Ether in pkt:
        ethertype = int(pkt[Ether].type)
        # LLDP EtherType 0x88cc; CDP commonly SNAP-decoded and detected by summary.
        if ethertype == 0x88CC:
            _save(source="passive", kind="neighbor", mac=pkt[Ether].src,
                  protocol="LLDP", confidence=0.95, details=json.dumps({"summary": pkt.summary()}))
            return
        summary = pkt.summary()
        if "CDP" in summary:
            _save(source="passive", kind="neighbor", mac=pkt[Ether].src,
                  protocol="CDP", confidence=0.9, details=json.dumps({"summary": summary}))
            return

    if IP in pkt:
        proto = int(pkt[IP].proto)
        names = {89: "OSPF", 112: "VRRP"}
        if proto in names:
            _save(source="passive", kind="routing_advertisement", ip=pkt[IP].src,
                  protocol=names[proto], confidence=0.9,
                  details=json.dumps({"dst": pkt[IP].dst, "summary": pkt.summary()}))

def capture(interface: str, seconds: int, pcap: str | None = None):
    kwargs = {"iface": interface, "prn": handle_packet, "store": False, "timeout": seconds}
    if pcap:
        from scapy.all import wrpcap
        packets = sniff(iface=interface, timeout=seconds)
        wrpcap(pcap, packets)
        for packet in packets:
            handle_packet(packet)
    else:
        sniff(**kwargs)
