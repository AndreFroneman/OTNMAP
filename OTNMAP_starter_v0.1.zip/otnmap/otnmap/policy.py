from dataclasses import dataclass
import random, time

@dataclass(frozen=True)
class SafetyProfile:
    name: str
    concurrency: int
    base_delay_ms: int
    jitter_ms: int
    max_probes_per_host: int
    active: bool

PROFILES = {
    "observe": SafetyProfile("observe", 0, 0, 0, 0, False),
    "fragile": SafetyProfile("fragile", 1, 750, 500, 12, True),
    "conservative": SafetyProfile("conservative", 4, 250, 250, 50, True),
    "lab": SafetyProfile("lab", 32, 10, 10, 500, True),
}

def pace(profile: SafetyProfile) -> None:
    delay = profile.base_delay_ms + random.randint(0, profile.jitter_ms)
    time.sleep(delay / 1000)
