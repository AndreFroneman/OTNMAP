"""
Authorized SNMPv3 table collection.

The exact OIDs supported by devices vary. This starter walks standard IP-MIB
tables and stores returned varbinds as evidence. Production code should map:
- IP-MIB ipNetToPhysicalTable / legacy ipNetToMediaTable
- IP-FORWARD-MIB inetCidrRouteTable / legacy ipCidrRouteTable
and add vendor-specific adapters.
"""
import asyncio, json
from pysnmp.hlapi.v3arch.asyncio import (
    SnmpEngine, UsmUserData, UdpTransportTarget, ContextData,
    ObjectType, ObjectIdentity, next_cmd,
    usmHMACSHAAuthProtocol, usmAesCfb128Protocol
)
from .db import SessionLocal, Observation

TABLES = {
    "arp_ipv4_legacy": "1.3.6.1.2.1.4.22",
    "neighbor_modern": "1.3.6.1.2.1.4.35",
    "route_legacy": "1.3.6.1.2.1.4.21",
    "route_modern": "1.3.6.1.2.1.4.24.7",
}

async def collect_tables(host: str, user: str, auth_key: str, priv_key: str):
    auth = UsmUserData(
        user, authKey=auth_key, privKey=priv_key,
        authProtocol=usmHMACSHAAuthProtocol,
        privProtocol=usmAesCfb128Protocol
    )
    target = await UdpTransportTarget.create((host, 161), timeout=3, retries=0)
    output = {}
    for name, oid in TABLES.items():
        rows = []
        iterator = next_cmd(
            SnmpEngine(), auth, target, ContextData(),
            ObjectType(ObjectIdentity(oid)), lexicographicMode=False
        )
        async for error_indication, error_status, error_index, var_binds in iterator:
            if error_indication or error_status:
                break
            for var_bind in var_binds:
                rows.append({"oid": str(var_bind[0]), "value": str(var_bind[1])})
            if len(rows) >= 5000:
                break
        output[name] = rows

    with SessionLocal() as db:
        db.add(Observation(
            source="snmpv3", kind="management_tables", ip=host,
            protocol="SNMPv3", confidence=1.0,
            details=json.dumps(output)
        ))
        db.commit()
    return output
