from otnmap.policy import PROFILES

def test_observe_is_passive():
    assert PROFILES["observe"].active is False
    assert PROFILES["observe"].max_probes_per_host == 0

def test_fragile_is_single_threaded():
    assert PROFILES["fragile"].concurrency == 1
